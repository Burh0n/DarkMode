const products = [
	{   
		title: 'Bulbasaur',
		img: './img/0.png',
		coin: 6.9,
		count: 2007,
		genre:'Action'
	},
	{
		title: 'Ivysaur',
		img: './img/0.png',
		coin: 10,
		count: 2005,
		genre:'Drama'
	},
	{
		title: 'Venusaur',
		img: './img/0.png', 
		coin: 9,
		count: 2001,
		genre:'Comedy'
	},
	{
		title: 'Charmander',
		img: './img/0.png',
		coin: 3,
		count: 2017,
		genre:'Action'
	},
	{
		title: 'Charmeleon',
		img: './img/0.png',
		coin: 6,
		count: 2000,
		genre:'Comedy'
	},
	{
		title: 'Charizard',
		img: './img/0.png',
		coin: 6,
		count: 2005,
		genre:'Drama'
	},
	{
		title: 'Squirtle',
		img: './img/0.png',
		coin: 8,
		count: 2005,
		genre:'Action'
	},
	{
		title: 'Wartortle',
		img: './img/0.png',
		coin: 5,
		count: 2021,
		genre:'Comedy'
	},
	{
		title: 'Blastoise',
		img: './img/0.png',
		coin: 9,
		count: 2006,
		genre:'Drama'
	},
	{
		title: 'Caterpie',
		img: './img/0.png',
		coin: 4,
		count: 2010,
		genre:'Drama'
	},
	{
		title: 'Metapod',
		img: './img/0.png',
		coin: 9,
		count: 2000,
		genre:'Action'
	},
	{
		title: 'Butterfree',
		img: './img/0.png',
		count: 1999,
		coin: 4,
		genre:'Drama'
	},
	{
		title: 'Butterfree',
		img: './img/0.png',
		count: 2009,
		coin: 4,
		genre:'Drama'
	},
	{
		title: 'Kakuna',
		img: './img/0.png',
		count: 1999,
		coin: 2,
		genre:'Comedy'
	},
	{
		title: 'Beedrill',
		img: './img/0.png',
		count: 1999,
		coin: 8,
		genre:'Comedy'
	},
	{
		title: 'Pidgey',
		img: './img/0.png',
		count: 2001,
		coin: 6,
		genre:'Action'
	},
	{
		title: 'Pidgeotto',
		img: './img/0.png',
		count: 2002,
		coin: 6,
		genre:'Drama'
	},
	{
		title: 'Pidgeotto',
		img: './img/0.png',
		count: 2022,
		coin: 7,
		genre:'Drama'
	},
	{
		title: 'Rattata',
		img: './img/0.png',
		count: 4999,
		coin: 6,
		genre:'Comedy'
	},
	{
		title: 'Raticate',
		img: './img/0.png',
		count: 2012,
		coin: 6,
		genre:'Drama'
	},
	{
		title: 'Raticate',
		img: './img/0.png',
		count: 2011,
		coin: 4,
		genre:'Action'
	},
	{
		title: 'Fearow',
		img: './img/0.png',
		count: 2015,
		coin: 4,
		genre:'Comedy'
	},
	{
		title: 'Ekans',
		img: './img/0.png',
		count: 2016,
		coin: 2,
		genre:'Drama'
	},
	{
		title: 'Arbok',
		img: './img/0.png',
		count: 2020,
		coin: 7,
		genre:'Action'
	},
	{
		title: 'Pikachu',
		img: './img/0.png',
		count: 2019,
		coin: 8,
		genre:'Action'
	},
	{
		title: 'Raichu',
		img: './img/0.png',
		coin: 4,
		count: 2009,
		genre:'Comedy'
	},
	{
		title: 'Sandshrew',
		img: './img/0.png',
		count: 2005,
		coin: 6,
		genre:'Action'
	},
	
	]

	


	//const category = document. querySelector ('#category')
	// 	category.addEventListener( 'change', e = {
	// 	let categoryInput = e.target.value
	// 	let categoryFilter = pokemons.filter(
	// 	item => item.type[0].toLowerCase() = categoryInput.toLowerCase()
	// 	)
	// 	render(categoryFilter.length ? categoryFilter : pokemons)
	// })
	const searchInput = document.querySelector('#searchInput')
	let cards = document.querySelector('.cards')
	
	
	searchInput.addEventListener('input', e => {
	
		let inputValue = e.target.value.toLowerCase();
	
		let filteredProducts = products.filter(item => 
			item.title.toLowerCase().includes(inputValue)
	)
		render(filteredProducts ? filteredProducts : products)
	
	
	});
	const sortInput = document.querySelector('#sort')
	
	sort.addEventListener('change' , e =>{
		let sortInput = e.target.value

		if(sortInput == 'a-z'){
			let ABC = products.sort((a, b) => a.title.localeCompare(b.title))
			render(ABC.length ? ABC : products)
		}else if(sortInput == 'z-a'){
			let ZYX = products.sort((a, b) =>b.title.localeCompare(a.title))
			render(ZYX.length ? ZYX :products)

		}
	})
	const genreInput = document.querySelector('#genre');

	genreInput.addEventListener('change', e => {
    let genreInput = e.target.value;

    
    if (genreInput === 'all') {
        render(products);
    } else {
        let genreSorted = products.filter(
            item => item.genre.toLowerCase() === genreInput.toLowerCase()
        );
        render(genreSorted.length ? genreSorted : products);
    }
});


	
	
	function render(array) {
		cards.innerHTML = ''
		array.map(item => {
			let box = document.createElement('div'); 
			box.classList.add('box1');

			let text = document.createElement('p'); 
			text.textContent = item.title;
			text.classList.add('movie')

			let btn = document.createElement('button')
			btn.classList.add('b')

			let img = document.createElement('img'); 
			img.src = item.img;
			img.classList.add('i')

			

			let number = document.createElement('div')
			number.classList.add('number')
			
			let genre = document.createElement('div')
			genre.textContent = item.genre
			genre.classList.add('genre')
			
	
			let span = document.createElement('span');
			span.classList.add('span');
	
			let coinIMG = document.createElement('img');
			coinIMG.src = '';

			let coin = document.createElement('h3')
			coin.classList.add('rang')
			coin.textContent = item.coin
	
			
	
			let span1 = document.createElement('span');
			span1.textContent = `${item.count} YIL`;
			span1.classList.add('span1')
	
			span.append(coinIMG);
			box.append( img,text, span, span1, coin, genre);
	
			cards.append(box);
		});
	}
	
	render(products)





